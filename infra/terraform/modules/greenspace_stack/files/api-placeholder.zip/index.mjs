export const handler = async () => ({ statusCode: 503, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Not deployed yet" }) });
